[2026-06-07 12:42:51] INIT
Obsidian Brain inicializado com sucesso
