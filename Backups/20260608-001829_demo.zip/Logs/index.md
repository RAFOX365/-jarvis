# Logs

## Histórico de Execuções

* Logs de automações
* Histórico de gerações (imagens/vídeos)
* Execuções de scripts

## Notas

Registre aqui eventos importantes do sistema Jarvis.
